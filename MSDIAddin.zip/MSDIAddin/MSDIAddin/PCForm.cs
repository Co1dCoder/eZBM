﻿namespace MSDIAddin
{
    public partial class PCForm : Bentley.MstnPlatformNET.WinForms.Adapter
                                 //System.Windows.Forms.Form
    {
        public PCForm()
        {
            InitializeComponent();
        }
    }
}
