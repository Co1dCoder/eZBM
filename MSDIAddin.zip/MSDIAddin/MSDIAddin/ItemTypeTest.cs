﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text.RegularExpressions;

using Bentley.GeometryNET;
using Bentley.DgnPlatformNET;
using Bentley.DgnPlatformNET.Elements;
using Bentley.DgnPlatformNET.DgnEC;
using Bentley.MstnPlatformNET;

using Bentley.ECObjects;
using Bentley.ECObjects.Schema;
using Bentley.ECObjects.Instance;


namespace MSDIAddin
{
    class ItemTypeTest
    {
        public static void CreateItemType(string itemLibName, string itemTypeName)
        {
            DgnFile dgnFile = Session.Instance.GetActiveDgnFile();
            ItemTypeLibrary itemTypeLibrary = ItemTypeLibrary.FindByName(itemLibName, dgnFile);
            if (null == itemTypeLibrary)
            {
                itemTypeLibrary = ItemTypeLibrary.Create(itemLibName, dgnFile);
            }
            itemTypeLibrary.AddItemType(itemTypeName);
            ItemType itemType = itemTypeLibrary.GetItemTypeByName(itemTypeName);
            CustomProperty intProperty = itemType.AddProperty("IntProperty");
            intProperty.Type = CustomProperty.TypeKind.Integer;
            CustomProperty strProperty = itemType.AddProperty("StrProperty");
            strProperty.Type = CustomProperty.TypeKind.String;
            itemTypeLibrary.Write();
        }
        public static void DeleteItemType(string itemLibName, string itemTypeName)
        {
            DgnFile dgnFile = Session.Instance.GetActiveDgnFile();
            ItemTypeLibrary itemTypeLibrary = ItemTypeLibrary.FindByName(itemLibName, dgnFile);
            if (null == itemTypeLibrary)
            {
                MessageBox.Show("Can't find itemType library!");
                return;
            }
            ItemType itemType = itemTypeLibrary.GetItemTypeByName(itemTypeName);
            itemTypeLibrary.RemoveItemType(itemType);
            itemTypeLibrary.Write();
        }
        public static void AttachItem(string itemLibName, string itemTypeName, ElementId elemId)
        {
            DgnModel dgnModel = Session.Instance.GetActiveDgnModel();
            Element elem = dgnModel.FindElementById(elemId);
            if (null == elem)
            {
                MessageBox.Show("Can't find element!");
                return;
            }

            DgnFile dgnFile = Session.Instance.GetActiveDgnFile();
            ItemTypeLibrary itemTypeLibrary = ItemTypeLibrary.FindByName(itemLibName, dgnFile);
            if (null == itemTypeLibrary)
            {
                MessageBox.Show("Can't find ItemType Library");
                return;
            }
            ItemType itemType = itemTypeLibrary.GetItemTypeByName(itemTypeName);

            CustomItemHost host = new CustomItemHost(elem, true);
            IDgnECInstance item = host.ApplyCustomItem(itemType, true);
            item.SetValue("IntProperty", 123);
            item.SetValue("StrProperty", "CCCC");

            item.ScheduleChanges(elem);
            elem.ReplaceInModel(elem);
        }
        // ECNameValidation.EncodeToValidName has bug in C#, correct in nativeCode C++
        private static string FurtherConvert(string inStr)
        {
            string rtnStr = inStr;
            string pa = @"^[a-zA-Z0-9]*$";
            Regex reg = new Regex(pa);
            Match mc = null;
            for (int i = 0; i < rtnStr.Length - 4; i++)
            {
                if (rtnStr.Substring(0, 2) == "__")
                {
                    string curMiddleStr = "";
                    int j = i + 2;
                    for (; j < rtnStr.Length; j++)
                    {
                        if (rtnStr[j] == '_')
                        {
                            curMiddleStr = rtnStr.Substring(i + 2, j - (i + 2));
                            break;
                        }
                    }
                    if (j > rtnStr.Length - 2)
                    {
                        break;
                    }
                    mc = reg.Match(curMiddleStr);
                    if (mc.Success)
                    {
                        if (rtnStr.Substring(j, 2) == "__")
                        {
                            string curTempStr = rtnStr.Substring(i, j + 2 - i);
                            if (curTempStr.Length == 9 && curTempStr[2] == 'x')
                            {
                                curTempStr = "__x" + curTempStr.Substring(3).ToUpper();
                                rtnStr = rtnStr.Substring(0, i - 0) + curTempStr + rtnStr.Substring(j + 2, rtnStr.Length - j - 2);
                            }
                        }
                    }
                }
            }
            return rtnStr;
        }

        public static void ReadItem(string itemLibName, string itemTypeName, ElementId elemId)
        {
            DgnModel dgnModel = Session.Instance.GetActiveDgnModel();
            Element elem = dgnModel.FindElementById(elemId);
            if (null == elem)
            {
                MessageBox.Show("Can't find element!");
                return;
            }
            CustomItemHost host = new CustomItemHost(elem, true);
            IDgnECInstance item = host.GetCustomItem(itemLibName, itemTypeName);

            DgnFile dgnFile = Session.Instance.GetActiveDgnFile();
            ItemTypeLibrary itemTypeLibrary = ItemTypeLibrary.FindByName(itemLibName, dgnFile);
            ItemType itemType = itemTypeLibrary.GetItemTypeByName(itemTypeName);
            CustomProperty property = itemType.GetPropertyByName("IntProperty");
            string internalName = property.InternalName;
            IECPropertyValue val = item.GetPropertyValue(internalName);
            MessageBox.Show(val != null ? val.StringValue : "val==null");
        }
        public static void DetachItem(string itemLibName, string itemTypeName, ElementId elemId)
        {
            DgnModel dgnModel = Session.Instance.GetActiveDgnModel();
            Element elem = dgnModel.FindElementById(elemId);
            Element newElem = elem;
            CustomItemHost host = new CustomItemHost(newElem, true);
            IDgnECInstance item = host.GetCustomItem(itemLibName, itemTypeName);

            item.ScheduleDelete(newElem);
            newElem.ReplaceInModel(elem);
        }
    }
}
